---
title: "Help description for key bindings"
categories: [feature, blog]
excerpt: "Key bindings are defined with help description, this feature is for getting Help description and jump to the position where the key bindings is defined."
image: https://user-images.githubusercontent.com/13142418/34907415-c2cf7e88-f843-11e7-92d3-ef0f9b1b72ae.gif
commentsID: "Help description for key bindings"
comments: true
---

# Help description for key bindings

Use `SPC h d k` to start a input prompt, Then press the key bindings you want to describe. 

![help description for key bindings](https://user-images.githubusercontent.com/13142418/34907415-c2cf7e88-f843-11e7-92d3-ef0f9b1b72ae.gif)

sometimes, you want to know the help description of a key binding and the definition of this key binding. this feature help you to quick get
these info.
