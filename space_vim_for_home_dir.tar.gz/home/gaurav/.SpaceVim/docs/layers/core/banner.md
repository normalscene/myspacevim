---
title: "SpaceVim core#banner layer"
description: "This layer provides many default banner on welcome page."
---

# [Available Layers](../) >> core#banner

<!-- vim-markdown-toc GFM -->

- [Description](#description)
- [Configuration](#configuration)

<!-- vim-markdown-toc -->

## Description

  This layer provides many default banner on welcome page. 

## Configuration

Currently, SpaceVim do not allowed to set the frequency.
