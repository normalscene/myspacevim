---
title: "SpaceVim core#statusline layer"
description: "This layer provides default statusline for SpaceVim"
---

# [Available Layers](../) >> core#statusline

<!-- vim-markdown-toc GFM -->

- [Description](#description)
- [Configuration](#configuration)

<!-- vim-markdown-toc -->

## Description

 This layer provides default statusline for SpaceVim.

## Configuration
  
All statusline key bindings can be find on [SpaceVim documentation](../../../documentation/#statusline)
  
