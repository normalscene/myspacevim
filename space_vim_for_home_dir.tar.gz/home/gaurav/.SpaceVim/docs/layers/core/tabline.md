---
title: "SpaceVim core#tabline layer"
description: "SpaceVim core#tabline layer provides a better tabline for SpaceVim"
---

# [Available Layers](../) >> core#tabline
  
## Intro
  
Different from airline, this layer provode a simple tabline for SpaceVim, which is more fast and compitable with SpaceVim's core feature.

## Key bindings

All tabline key bindings can be find on [SpaceVim documentation](../../../documentation/#tabline)



