---
title: "SpaceVim core layer"
description: "SpaceVim core layer provides many default key bindings and features."
---

# [Available Layers](../) >> core
 
<!-- vim-markdown-toc GFM -->

- [Intro](#intro)
- [Features](#features)
- [Configuration](#configuration)

<!-- vim-markdown-toc -->

## Intro
 
## Features
 
## Configuration
 
