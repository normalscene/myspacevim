---
title: "SpaceVim core 模块"
description: "core 模块主要包括 SpaceVim 启动及基本操作所必须的插件及配置。"
lang: cn
---

# [可用模块](../) >> core
 
## 模块简介

该模块主要包括 SpaceVim 启动时所必须的配置，默认已启用。

## 功能特性

- 文件树：nerdtree 或者 vimfiler，默认为 vimfiler，由 `filemanager` 选项控制
