---
title: "SpaceVim core#statusline 模块"
description: "这一模块为 SpaceVim 提供了默认的模式化的状态栏支持。"
lang: cn
---

# [可用模块](../) >> core#statusline

<!-- vim-markdown-toc GFM -->

- [模块简介](#模块简介)
- [模块启用](#模块启用)
- [相关选项](#相关选项)

<!-- vim-markdown-toc -->

## 模块简介

这一模块为 SpaceVim 提供了默认的模式化的状态栏支持。

## 模块启用

可通过在配置文件内加入如下配置来启用该模块，该模块默认已经启用：

```toml
[[layers]]
  name = "core#statusline"
```

## 相关选项

在这里，将列出一些跟状态了相关的 SpaceVim 相关选项，这些选项并非模块选项，需加以区分：

