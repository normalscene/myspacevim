---
title: "SpaceVim core#banner 模块"
description: "This layer provides many default banner on welcome page."
lang: cn
---

# [Available Layers](../) >> core#banner

<!-- vim-markdown-toc GFM -->

- [模块简介](#模块简介)
- [模块选项](#模块选项)

<!-- vim-markdown-toc -->

## 模块简介

这一模块主要是为 SpaceVim 设置一些默认的启动界面的 logo。

## 模块选项
 
- frequece for change the banner: daily, weekly, or other.
 


