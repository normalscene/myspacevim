---
title: "SpaceVim lang#autohotkey 模块"
description: "这一个模块为 SpaceVim 提供了 autohotkey 语言的开发支持，包括语法高亮和自动补全等功能。"
lang: cn
---

# [可用模块](../../) >> lang#autohotkey

<!-- vim-markdown-toc GFM -->

- [模块简介](#模块简介)
- [功能特性](#功能特性)
- [启用模块](#启用模块)

<!-- vim-markdown-toc -->

## 模块简介

这一个模块为 SpaceVim 提供了 autohotkey 语言的开发支持。

## 功能特性

- 语法高亮
- 自动补全

## 启用模块

可通过在配置文件内加入如下配置来启用该模块：

```toml
[[layers]]
  name = "lang#autohotkey"
```
