---
title: "SpaceVim lang#javascript 模块"
description: "这一模块为 javascript 开发提供支持，包括代码补全、语法检查、代码格式化等特性。"
lang: cn
---

# [可用模块](../../) >> lang#javascript

<!-- vim-markdown-toc GFM -->

- [模块简介](#模块简介)
- [启用模块](#启用模块)
- [功能特性](#功能特性)
- [模块配置](#模块配置)
- [快捷键](#快捷键)
  - [导包相关快捷键](#导包相关快捷键)
  - [常规快捷键](#常规快捷键)

<!-- vim-markdown-toc -->

## 模块简介

这一模块为 SpaceVim 提供了 javascript 开发支持，包括代码补全、语法检查、以及代码格式化等特性。

## 启用模块

可通过在配置文件内加入如下配置来启用该模块：

```toml
[[layers]]
  name = "lang#javascript"
```

## 功能特性

- 代码补全
- 语法检查
- 跳转定义处
- 查询函数引用

## 模块配置

- `auto_fix`：保存文件时，自动修复代码问题，默认未启用该功能，若需要该功能，可在载入模块时设置该选项为 `true`。
- `enable_flow_syntax`: 启用/禁用 [flow](https://flow.org/) 语法高亮，默认未启用。

配置示例：

```toml
[[layers]]
  name = "lang#javascript"
  auto_fix = true
  enable_flow_syntax = true
```

## 快捷键

### 导包相关快捷键

| 模式          | 快捷键    | 按键描述           |
| ------------- | --------- | ------------------ |
| Insert/Normal | `F4`      | 导入光标下的类     |
| Normal        | `SPC l I` | 导入所有缺失的类   |
| Normal        | `SPC l R` | 删除多余的导包     |
| Normal        | `SPC l i` | 智能导入光标下的类 |
| Insert        | `<C-j>I`  | 导入所有缺失的类   |
| Insert        | `<C-j>R`  | 删除多余的导包     |
| Insert        | `<C-j>i`  | 智能导入光标下的类 |

### 常规快捷键

| 模式   | 快捷键      | 按键描述   |
| ------ | ----------- | ---------- |
| normal | `SPC l g d` | 生成 JSDoc |
